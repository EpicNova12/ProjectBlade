#pragma once
#include "Application/ApplicationLayer.h"
#include "Gameplay/Material.h"
#include "json.hpp"

/**
 * This example layer handles creating a default test scene, which we will use 
 * as an entry point for creating a sample scene
 */
class DefaultSceneLayer final : public ApplicationLayer {
public:
	MAKE_PTRS(DefaultSceneLayer)

	DefaultSceneLayer();
	virtual ~DefaultSceneLayer();

	// Inherited from ApplicationLayer

	virtual void OnAppLoad(const nlohmann::json& config) override;
	virtual void OnUpdate() override;
protected:
	std::vector <Gameplay::Material::Sptr> materials;
	void _CreateScene();
};